package com.github.sd4324530.fastweixin.message.req;

public class BaseReqMsg extends BaseReq {

	String msgId;

	public String getMsgId() {
		return msgId;
	}

	public void setMsgId(String msgId) {
		this.msgId = msgId;
	}

}
